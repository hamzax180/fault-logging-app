package com.example.faultapp;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

public class EditFaultActivity extends AppCompatActivity {

    TextInputEditText editTitle, editDescription;
    MaterialButton btnUpdate, btnCancel;
    DBHelper dbHelper;
    int faultId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_fault);

        dbHelper = new DBHelper(this);

        editTitle = findViewById(R.id.editTitle);
        editDescription = findViewById(R.id.editDescription);
        btnUpdate = findViewById(R.id.btnUpdate);
        btnCancel = findViewById(R.id.btnDelete); // reused as cancel

        Intent intent = getIntent();
        faultId = intent.getIntExtra("FAULT_ID", -1);
        String title = intent.getStringExtra("TITLE");
        String desc = intent.getStringExtra("DESCRIPTION");

        Log.d("EditFault", "Received fault ID: " + faultId);
        Log.d("EditFault", "Received title: " + title);
        Log.d("EditFault", "Received description: " + desc);

        if (faultId == -1) {
            Toast.makeText(this, "Invalid fault ID", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        editTitle.setText(title);
        editDescription.setText(desc);

        btnUpdate.setOnClickListener(v -> {
            String newTitle = editTitle.getText().toString().trim();
            String newDesc = editDescription.getText().toString().trim();

            if (newTitle.isEmpty() || newDesc.isEmpty()) {
                Toast.makeText(this, "Fill in all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            Log.d("EditFault", "Trying to update ID " + faultId + " with: " + newTitle + ", " + newDesc);
            boolean updated = dbHelper.updateFault(faultId, newTitle, newDesc);

            if (updated) {
                Toast.makeText(this, "Updated!", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(this, "Update failed", Toast.LENGTH_SHORT).show();
            }
        });

        btnCancel.setOnClickListener(v -> finish());
    }
}
