package com.example.faultapp;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.button.MaterialButton;

public class HomeActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        MaterialButton addNew = findViewById(R.id.home_btn_addnew);
        MaterialButton seeAll = findViewById(R.id.home_btn_seeall);

        addNew.setOnClickListener(v -> {
            Intent intent = new Intent(HomeActivity.this, RegisterNewActivity.class);
            startActivity(intent);
        });

        seeAll.setOnClickListener(v -> {
            Intent intent = new Intent(HomeActivity.this, SeeAllActivity.class);
            startActivity(intent);
        });
    }
}