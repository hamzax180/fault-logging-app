package com.example.faultapp;

import android.os.Bundle;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

public class SignupActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        TextInputEditText username = findViewById(R.id.edtUsername);
        TextInputEditText password = findViewById(R.id.edtPassword);
        MaterialButton signUp = findViewById(R.id.btnSignUp);

        signUp.setOnClickListener(v -> {
            String user = username.getText().toString().trim();
            String pass = password.getText().toString().trim();
            if (!user.isEmpty() && !pass.isEmpty()) {
                Toast.makeText(this, "Registered!", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Please fill both fields.", Toast.LENGTH_SHORT).show();
            }
        });
    }
}