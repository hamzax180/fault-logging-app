package com.example.faultapp;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class SeeAllActivity extends AppCompatActivity {

    LinearLayout container, emptyStateLayout;
    TextView noFaultsText;
    DBHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_see_all);

        container = findViewById(R.id.container);
        emptyStateLayout = findViewById(R.id.emptyStateLayout);
        noFaultsText = findViewById(R.id.noFaultsText);

        db = new DBHelper(this);
        showAllFaults();  // Load initially
    }

    @Override
    protected void onResume() {
        super.onResume();
        showAllFaults();  // Refresh after returning from Edit
    }

    private void showAllFaults() {
        container.removeAllViews();
        Cursor cursor = db.getAllFaults();

        if (cursor.getCount() == 0) {
            emptyStateLayout.setVisibility(View.VISIBLE);
            container.setVisibility(View.GONE);
        } else {
            emptyStateLayout.setVisibility(View.GONE);
            container.setVisibility(View.VISIBLE);

            LayoutInflater inflater = LayoutInflater.from(this);

            while (cursor.moveToNext()) {
                int id = cursor.getInt(0);
                String title = cursor.getString(1);
                String desc = cursor.getString(2);

                View faultItem = inflater.inflate(R.layout.item_fault, container, false);

                TextView titleView = faultItem.findViewById(R.id.faultTitle);
                TextView descView = faultItem.findViewById(R.id.faultDescription);
                Button updateBtn = faultItem.findViewById(R.id.btnUpdate);
                Button deleteBtn = faultItem.findViewById(R.id.btnDelete);

                titleView.setText("Title: " + title);
                descView.setText("Description: " + desc);

                updateBtn.setOnClickListener(v -> {
                    Intent intent = new Intent(SeeAllActivity.this, EditFaultActivity.class);
                    intent.putExtra("FAULT_ID", id);
                    intent.putExtra("TITLE", title);
                    intent.putExtra("DESCRIPTION", desc);
                    startActivity(intent);
                });

                deleteBtn.setOnClickListener(v -> {
                    db.deleteFault(id);
                    showAllFaults();  // refresh after delete
                });

                container.addView(faultItem);
            }
        }
    }
}
