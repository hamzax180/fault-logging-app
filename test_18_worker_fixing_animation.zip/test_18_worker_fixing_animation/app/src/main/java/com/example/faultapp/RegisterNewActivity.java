package com.example.faultapp;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

public class RegisterNewActivity extends AppCompatActivity {

    private DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_new);

        dbHelper = new DBHelper(this);

        TextInputEditText titleField = findViewById(R.id.edtTitle);
        TextInputEditText descField = findViewById(R.id.edtDescription);
        MaterialButton saveBtn = findViewById(R.id.btnSave);

        saveBtn.setOnClickListener(v -> {
            String title = titleField.getText().toString().trim();
            String desc = descField.getText().toString().trim();
            Log.d("INPUT", "Title: " + title + ", Desc: " + desc);

            if (!title.isEmpty() && !desc.isEmpty()) {
                boolean success = dbHelper.insertFault(title, desc);
                if (success) {
                    Toast.makeText(this, "Fault saved!", Toast.LENGTH_SHORT).show();
                    titleField.setText("");
                    descField.setText("");
                } else {
                    Toast.makeText(this, "Failed to save fault.", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(this, "Please fill in both fields.", Toast.LENGTH_SHORT).show();
            }
        });
    }
}